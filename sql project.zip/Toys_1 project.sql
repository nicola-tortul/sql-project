CREATE DATABASE Toys_1
USE Toys_1

CREATE TABLE ProductCategory (
CategoryID INT,
CategoryName VARCHAR (25),
CONSTRAINT PK_CategoryID PRIMARY KEY (CategoryID)
)

INSERT INTO ProductCategory (CategoryID, CategoryName)
VALUES (1, 'Toys'), (2, 'Puzzle'), (3, 'Video Games'), (4, 'Accessories'), (5, 'Board Games')

CREATE TABLE Region (
RegionID INT,
RegionName VARCHAR (25),
CONSTRAINT PK_RegionID PRIMARY KEY (RegionID)
);

INSERT INTO Region (RegionID, RegionName)
VALUES (1, 'NorthEurope'), (2, 'SouthEurope'), (3, 'WestEurope')
, (4, 'NorthAmerica'), (5, 'SouthAmerica'), (6, 'EastAsia'), (7, 'SouthAsia')


CREATE TABLE State(
StateID INT,
StateName VARCHAR (25),
RegionID INT,
CONSTRAINT PK_StateID PRIMARY KEY (StateID),
CONSTRAINT FK_RegionID FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);


INSERT INTO State (StateID, StateName, RegionID)
VALUES (1, 'Italy', 2), (2, 'Norway', 1), (3, 'Alabama', 4), (4, 'Japan', 6), (5, 'China', 7),
(6, 'Chile', 5), (7, 'Brasil', 5), (8, 'Texas', 4), (9, 'Virginia', 4), (10, 'Kansas', 4),
(11, 'India', 7), (12, 'Colombia', 5), (13, 'France', 3), (14, 'Denmark', 1);


CREATE TABLE Product (
ProductID INT,
ProductName VARCHAR (25),
CategoryID INT,
ListPrice DECIMAL (5,2),
CONSTRAINT PK_ProductID PRIMARY KEY (ProductID),
CONSTRAINT FK_CategoryID FOREIGN KEY (CategoryID) REFERENCES ProductCategory(CategoryID)
);

INSERT INTO Product (ProductID, ProductName, CategoryID, ListPrice)  
VALUES (100, 'Lego', 1, 99.99 ), (101, 'Frozen', 1, 12.90), (102, 'Games', 3, 69.90), (103, 'Barbie', 2, 79.99), (104, 'Risiko', 5, 49.90),
(105, 'Bing', 2, 14.90), (106, 'Xbox', 3, 499.00), (107, 'Play Station', 3, 549.00), (108, 'Joypad', 4, 80.00 ), (109, 'Monopoli', 5, 39.90),
(110, 'Toy Story', 2, 19.90), (111, 'Escape the dark castle', 5, 34.90), (112, 'Dead of winter', 5, 59.90), (113, 'Headset', 4, 27.90),
(114, 'Forza Motorsport 8', 3, 79.90), (115, 'Bing', 1, 21.90), (116, 'Talisman', 5, 49.99);


CREATE TABLE Sales (
SalesID INT,
SalesOrderLine INT,
Quantity INT,
OrderDate DATE,
SalesAmount DECIMAL (20,2),
ProductID INT,
StateID INT,
CONSTRAINT PK_SalesID PRIMARY KEY (SalesID),
CONSTRAINT FK_ProductID FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
CONSTRAINT FK_StateID_Sales FOREIGN KEY (StateID) REFERENCES State(StateID)
);

INSERT INTO Sales (SalesID, SalesOrderLine, Quantity, OrderDate, SalesAmount, ProductID, StateID)
VALUES (0001, 1, 180, '2023-06-02', 17998.20, 100, 2),
(0002, 2, 360, '2023-01-21', 14364.00, 102, 5),
(0003, 3, 247, '2022-12-21', 4915.30, 110, 1),
(0004, 4, 190, '2023-04-3', 2451.00, 101, 3),
(0005, 5, 1800, '2023-12-23', 125820.00, 102, 4),
(0006, 6, 920, '2022-09-12', 32108.00, 111, 13),
(0007, 7, 12560, '2023-03-14', 752344.00, 112, 9),
(0008, 8, 6505, '2023-08-10', 3571245.00, 107, 8),
(0009,9, 7600, '2023-11-26', 3792400.00, 106, 7),
(0010, 10, 8900, '2022- 04-23', 712000.00, 112, 10),
(0011, 11, 860, '2023-05-30', 68791.00, 110, 14),
(0012, 12, 4200, '2022-10-09', 209580.00, 104, 6),
(0013, 13, 2890, '2022- 07-23', 43061.00, 102, 1),
(0014, 14, 1050, '2024-02-12', 54489.5, 116, 8),
(0015, 15, 375, '2024-01-06', 10875, 113, 13),
(0016, 16, 5000, '2023-10-27', 399500, 114, 13),
(0017, 17, 6900, '2024- 02-12', 3443100, 106, 10);


-- 1) Verify that the fields defined as PK are unique

SELECT CategoryID, COUNT(*) AS TotCount
FROM ProductCategory
GROUP BY   CategoryID
HAVING COUNT(*) > 1


SELECT RegionID, COUNT(*) AS TotCount
FROM Region
GROUP BY   RegionID
HAVING COUNT(*) > 1

SELECT StateID, COUNT(*) AS TotCount
FROM State
GROUP BY   StateID
HAVING COUNT(*) > 1

SELECT ProductID, COUNT(*) AS TotCount
FROM Product
GROUP BY   ProductID
HAVING COUNT(*) > 1

SELECT SalesID, COUNT(*) AS TotCount
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1


/* 2) Exhibit the list of transactions by indicating in the result set the document code, date, product name, 
product category, state name, sales region name, and a Boolean field valued according to the condition whether more than 180 days 
have passed since the sale date or not (>180 -> True, <= 180 -> False) */

SELECT SalesID, ProductName, CategoryName, OrderDate, StateName, RegionName,
CASE WHEN DATEDIFF(Day, OrderDate, GETDATE()) > 180 THEN 1 ELSE 0 END AS DateDisplay
FROM ProductCategory AS pc
JOIN Product AS p ON pc.CategoryID = p.CategoryID
JOIN Sales AS s ON p.ProductID = s.ProductID
JOIN State AS st ON s.StateID = st.StateID
JOIN Region AS r ON st.RegionID = r.RegionID


-- 3) Exhibit the list of only products sold and for each of these the total sales by year

SELECT p.ProductID, ProductName, SUM(SalesAmount) AS TotSales, YEAR(OrderDate) as Year
FROM Sales AS s
JOIN  Product AS p ON s.ProductID = p.ProductID
GROUP BY p.ProductID, ProductName, OrderDate
ORDER BY Year DESC


-- 4) Display total turnover by state by year. Sort the result by date and by decreasing turnover

SELECT StateName, SUM(SalesAmount) AS TotSales, YEAR(OrderDate) AS Year
FROM Sales AS s
JOIN State AS st ON s.StateID = st.StateID
GROUP BY  StateName, OrderDate
ORDER BY YEAR(OrderDate), TotSales DESC


-- 5) what is the category of items most in demand in the market?

SELECT CategoryName, COUNT(pc.CategoryID) AS CategoryCount
FROM Sales AS s
JOIN Product AS p ON s.ProductID = p.ProductID
JOIN ProductCategory AS pc ON p.CategoryID = pc.CategoryID
GROUP BY CategoryName
ORDER BY CategoryCount DESC 


-- 6) What, if any, are the unsold products? 

-- first approach
SELECT p.ProductID, ProductName, SalesAmount
FROM Sales AS s
RIGHT JOIN Product AS p ON s.ProductID = p.ProductID
WHERE SalesAmount IS NULL

-- second approach
SELECT p.ProductID, ProductName
FROM Product AS p
WHERE p.ProductID NOT IN (SELECT s.ProductID
							FROM Sales AS s
							WHERE Quantity > 0) -- we could also omit the where clause, the result would be the same


-- 7) Display the list of products witha respective last date of sale (the most recent date of sale)

SELECT s1.ProductID, s1.OrderDate
FROM Sales AS s1
WHERE OrderDate IN (SELECT MAX(s2.OrderDate)
					FROM Sales AS s2
					WHERE s1.SalesID = s2.SalesID)
GROUP BY s1.ProductID, s1.OrderDate
ORDER BY s1.OrderDate DESC


/* 8) Create a product view in such a way as to expose a "denormalized version" 
of useful information (product code, product name, category name)
*/

CREATE VIEW VW_NT_Products 
AS (
SELECT ProductID, ProductName, C.CategoryID, CategoryName
FROM Product AS p JOIN ProductCategory AS c
ON p.CategoryID = c.CategoryID)


-- 9) Create view to return a "denormalized" version of geographic information

CREATE VIEW VW_NT_Geography
AS (
SELECT StateID, StateName, R.RegionID, RegionName	
FROM STATE AS S
JOIN Region AS r ON s.RegionID = r.RegionID)









